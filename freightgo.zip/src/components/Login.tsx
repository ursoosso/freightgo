import React, { useState } from 'react';
import { auth, signInWithPopup, GoogleAuthProvider, handleFirestoreError, OperationType } from '../firebase';
import { LogIn, Truck, Shield, MapPin, Navigation } from 'lucide-react';
import { motion } from 'motion/react';

export default function Login() {
  const [loading, setLoading] = useState(false);

  const handleGoogleLogin = async () => {
    setLoading(true);
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, 'auth/login');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid lg:grid-cols-2">
      {/* Left Side: Branding & Info */}
      <div className="hidden lg:flex flex-col justify-center p-12 bg-[#1E293B] text-white relative overflow-hidden">
        <div className="relative z-10">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex items-center gap-3 mb-8"
          >
            <Truck className="w-12 h-12 text-[#F97316]" />
            <h1 className="text-5xl font-black tracking-tighter">FreightGo</h1>
          </motion.div>
          
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-3xl font-bold mb-6 max-w-md"
          >
            A solução inteligente para o seu transporte de carga.
          </motion.h2>

          <div className="space-y-6">
            {[
              { icon: Shield, text: "Segurança garantida em cada entrega." },
              { icon: MapPin, text: "Rastreamento em tempo real para sua tranquilidade." },
              { icon: Navigation, text: "Conectando você aos melhores motoristas." }
            ].map((item, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.2 + i * 0.1 }}
                className="flex items-center gap-4 text-gray-300"
              >
                <item.icon className="w-6 h-6 text-[#F97316]" />
                <span className="text-lg">{item.text}</span>
              </motion.div>
            ))}
          </div>
        </div>
        
        {/* Background Decoration */}
        <div className="absolute -bottom-20 -right-20 w-96 h-96 bg-[#F97316] opacity-10 rounded-full blur-3xl" />
        <div className="absolute top-20 left-20 w-64 h-64 bg-blue-500 opacity-5 rounded-full blur-3xl" />
      </div>

      {/* Right Side: Login Form */}
      <div className="flex flex-col justify-center items-center p-8 bg-white">
        <div className="max-w-md w-full text-center">
          <div className="lg:hidden flex items-center justify-center gap-2 mb-12">
            <Truck className="w-8 h-8 text-[#F97316]" />
            <h1 className="text-3xl font-black tracking-tighter text-[#1E293B]">FreightGo</h1>
          </div>

          <h2 className="text-3xl font-bold text-[#1E293B] mb-2">Bem-vindo de volta!</h2>
          <p className="text-gray-500 mb-12 text-lg">Entre para gerenciar seus fretes com facilidade.</p>

          <button
            onClick={handleGoogleLogin}
            disabled={loading}
            className="w-full flex items-center justify-center gap-4 py-4 px-6 border-2 border-gray-100 rounded-2xl font-bold text-gray-700 hover:bg-gray-50 hover:border-gray-200 transition-all disabled:opacity-50"
          >
            <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" alt="Google" className="w-6 h-6" />
            {loading ? 'Entrando...' : 'Entrar com Google'}
          </button>

          <p className="mt-12 text-gray-400 text-sm">
            Ao entrar, você concorda com nossos <a href="#" className="text-[#F97316] font-semibold">Termos de Uso</a> e <a href="#" className="text-[#F97316] font-semibold">Política de Privacidade</a>.
          </p>
        </div>
      </div>
    </div>
  );
}
