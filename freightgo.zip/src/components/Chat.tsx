import React, { useState, useEffect, useRef } from 'react';
import { db, collection, addDoc, query, where, orderBy, onSnapshot, handleFirestoreError, OperationType } from '../firebase';
import { Send, User, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { useAuth } from '../App';

interface Message {
  id: string;
  freightId: string;
  senderId: string;
  senderName: string;
  text: string;
  createdAt: string;
}

interface ChatProps {
  freightId: string;
  otherPartyName: string;
}

export default function Chat({ freightId, otherPartyName }: ChatProps) {
  const { profile } = useAuth();
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const q = query(
      collection(db, 'freights', freightId, 'messages'),
      orderBy('createdAt', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setMessages(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Message)));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, `freights/${freightId}/messages`);
    });

    return () => unsubscribe();
  }, [freightId]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !profile) return;

    const messageData = {
      freightId,
      senderId: profile.uid,
      senderName: profile.name,
      text: newMessage.trim(),
      createdAt: new Date().toISOString()
    };

    try {
      setNewMessage('');
      await addDoc(collection(db, 'freights', freightId, 'messages'), messageData);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `freights/${freightId}/messages`);
    }
  };

  return (
    <div className="flex flex-col h-[500px] bg-gray-50 rounded-2xl overflow-hidden border border-gray-100">
      {/* Chat Header */}
      <div className="p-4 bg-white border-bottom border-gray-100 flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-orange-50 flex items-center justify-center">
          <User className="w-5 h-5 text-[#F97316]" />
        </div>
        <div>
          <p className="font-bold text-[#1E293B]">{otherPartyName}</p>
          <p className="text-xs text-green-500 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-green-500" />
            Online
          </p>
        </div>
      </div>

      {/* Messages Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 space-y-4 scroll-smooth"
      >
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <motion.div
              animate={{ rotate: 360 }}
              transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
              className="w-6 h-6 border-2 border-[#F97316] border-t-transparent rounded-full"
            />
          </div>
        ) : messages.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-gray-400 space-y-2">
            <Clock className="w-8 h-8 opacity-20" />
            <p className="text-sm">Inicie a conversa sobre o frete</p>
          </div>
        ) : (
          messages.map((msg) => (
            <motion.div
              key={msg.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${msg.senderId === profile?.uid ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`max-w-[80%] p-3 rounded-2xl ${
                msg.senderId === profile?.uid 
                  ? 'bg-[#1E293B] text-white rounded-tr-none' 
                  : 'bg-white text-[#1E293B] rounded-tl-none shadow-sm'
              }`}>
                <p className="text-sm">{msg.text}</p>
                <p className={`text-[10px] mt-1 opacity-50 ${
                  msg.senderId === profile?.uid ? 'text-right' : 'text-left'
                }`}>
                  {new Date(msg.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </p>
              </div>
            </motion.div>
          ))
        )}
      </div>

      {/* Input Area */}
      <form onSubmit={handleSendMessage} className="p-4 bg-white border-t border-gray-100">
        <div className="relative">
          <input
            type="text"
            placeholder="Digite sua mensagem..."
            className="w-full pl-4 pr-12 py-3 bg-gray-50 border-2 border-transparent focus:border-[#F97316] focus:bg-white rounded-xl transition-all outline-none text-sm"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
          />
          <button
            type="submit"
            disabled={!newMessage.trim()}
            className="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-[#F97316] hover:bg-orange-50 rounded-lg transition-all disabled:opacity-30"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </form>
    </div>
  );
}
