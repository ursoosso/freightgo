import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../App';
import { User, Settings, LogOut, Truck, ChevronDown, Star, Shield, History, Wallet, HelpCircle, Gift, ChevronRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function UserMenu() {
  const { profile, signOut, switchRole, openProfile, openSettings, openHistory, openWallet, openPromos, openHelp } = useAuth();
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  if (!profile) return null;

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-3 p-1.5 pr-4 rounded-2xl bg-white border border-gray-100 shadow-sm hover:shadow-md transition-all group"
      >
        <div className="relative">
          <img
            src={profile.photoUrl || `https://picsum.photos/seed/${profile.uid}/100/100`}
            alt={profile.name}
            className="w-10 h-10 rounded-xl object-cover border-2 border-white"
          />
          <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full border-2 border-white ${profile.role === 'driver' ? 'bg-[#F97316]' : 'bg-blue-500'}`} />
        </div>
        <div className="text-left hidden sm:block">
          <p className="text-sm font-bold text-[#1E293B] leading-tight">{profile.name}</p>
          <p className="text-[10px] font-black uppercase tracking-widest text-gray-400">
            {profile.role === 'client' ? 'Cliente' : 'Motorista'}
          </p>
        </div>
        <ChevronDown className={`w-4 h-4 text-gray-400 transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 10, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 10, scale: 0.95 }}
            className="absolute right-0 mt-3 w-80 bg-white rounded-3xl shadow-2xl border border-gray-100 overflow-hidden z-[1000]"
          >
            {/* Profile Header */}
            <div className="p-6 bg-gray-50/50 border-b border-gray-100">
              <div className="flex items-center gap-4 mb-4">
                <img
                  src={profile.photoUrl || `https://picsum.photos/seed/${profile.uid}/100/100`}
                  alt={profile.name}
                  className="w-14 h-14 rounded-2xl object-cover shadow-sm"
                />
                <div>
                  <p className="font-black text-lg text-[#1E293B] leading-tight">{profile.name}</p>
                  <div className="flex items-center gap-2 mt-1">
                    <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-yellow-100 text-yellow-700 text-[10px] font-bold">
                      <Star className="w-2.5 h-2.5 fill-current" />
                      {profile.rating?.toFixed(1)}
                    </div>
                    {profile.isVerified && (
                      <div className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-green-100 text-green-700 text-[10px] font-bold">
                        <Shield className="w-2.5 h-2.5" />
                        Verificado
                      </div>
                    )}
                  </div>
                </div>
              </div>
              <p className="text-xs text-gray-500 font-medium truncate">{profile.email}</p>
            </div>

            {/* Menu Sections */}
            <div className="p-3 max-h-[70vh] overflow-y-auto">
              {/* Account Section */}
              <div className="mb-2">
                <p className="px-3 py-2 text-[10px] font-black text-gray-400 uppercase tracking-widest">Conta</p>
                <button 
                  onClick={() => { setIsOpen(false); openProfile(); }}
                  className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-gray-50 transition-all text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-500 group-hover:scale-110 transition-transform">
                      <User className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#1E293B]">Meu Perfil</p>
                      <p className="text-[10px] text-gray-400">Dados e preferências</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-300" />
                </button>

                <button 
                  onClick={() => { setIsOpen(false); openSettings(); }}
                  className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-gray-50 transition-all text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-purple-50 flex items-center justify-center text-purple-500 group-hover:scale-110 transition-transform">
                      <Settings className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#1E293B]">Configurações</p>
                      <p className="text-[10px] text-gray-400">Segurança e notificações</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-300" />
                </button>
              </div>

              {/* Activity Section */}
              <div className="mb-2">
                <p className="px-3 py-2 text-[10px] font-black text-gray-400 uppercase tracking-widest">Atividade</p>
                <button 
                  onClick={() => { setIsOpen(false); openHistory(); }}
                  className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-gray-50 transition-all text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-500 group-hover:scale-110 transition-transform">
                      <History className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#1E293B]">Meus Fretes</p>
                      <p className="text-[10px] text-gray-400">Histórico de viagens</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-300" />
                </button>

                <button 
                  onClick={() => { setIsOpen(false); openWallet(); }}
                  className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-gray-50 transition-all text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-green-50 flex items-center justify-center text-green-500 group-hover:scale-110 transition-transform">
                      <Wallet className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#1E293B]">Carteira</p>
                      <p className="text-[10px] text-gray-400">Pagamentos e ganhos</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-300" />
                </button>
              </div>

              {/* Support Section */}
              <div className="mb-2">
                <p className="px-3 py-2 text-[10px] font-black text-gray-400 uppercase tracking-widest">Suporte</p>
                <button 
                  onClick={() => { setIsOpen(false); openPromos(); }}
                  className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-gray-50 transition-all text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-pink-50 flex items-center justify-center text-pink-500 group-hover:scale-110 transition-transform">
                      <Gift className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#1E293B]">Promoções</p>
                      <p className="text-[10px] text-gray-400">Cupons e descontos</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-300" />
                </button>

                <button 
                  onClick={() => { setIsOpen(false); openHelp(); }}
                  className="w-full flex items-center justify-between p-3 rounded-2xl hover:bg-gray-50 transition-all text-left group"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-teal-50 flex items-center justify-center text-teal-500 group-hover:scale-110 transition-transform">
                      <HelpCircle className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="text-sm font-bold text-[#1E293B]">Ajuda</p>
                      <p className="text-[10px] text-gray-400">Central de atendimento</p>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-300" />
                </button>
              </div>

              <div className="my-2 border-t border-gray-100" />

              {/* Role Switch */}
              <button
                onClick={() => { setIsOpen(false); switchRole(); }}
                className="w-full flex items-center gap-3 p-3 rounded-2xl bg-orange-50 hover:bg-orange-100 transition-all text-left group"
              >
                <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center text-[#F97316] shadow-sm group-hover:rotate-180 transition-transform duration-500">
                  {profile.role === 'client' ? <Truck className="w-5 h-5" /> : <User className="w-5 h-5" />}
                </div>
                <div>
                  <p className="text-sm font-bold text-[#F97316]">Mudar para {profile.role === 'client' ? 'Motorista' : 'Cliente'}</p>
                  <p className="text-[10px] text-orange-400/80">Alternar modo de uso</p>
                </div>
              </button>

              {/* Logout */}
              <button
                onClick={signOut}
                className="w-full flex items-center gap-3 p-3 mt-2 rounded-2xl hover:bg-red-50 transition-all text-left group"
              >
                <div className="w-10 h-10 rounded-xl bg-red-50 flex items-center justify-center text-red-500 group-hover:translate-x-1 transition-transform">
                  <LogOut className="w-5 h-5" />
                </div>
                <div>
                  <p className="text-sm font-bold text-red-500">Sair da Conta</p>
                  <p className="text-[10px] text-red-300">Encerrar sessão atual</p>
                </div>
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
