import React, { createContext, useContext, useEffect, useState, useRef } from 'react';
import { auth, db, onAuthStateChanged, User, doc, getDoc, setDoc, updateDoc, onSnapshot, handleFirestoreError, OperationType } from './firebase';
import { LogIn, Truck, User as UserIcon, MapPin, Navigation, Package, Star, Shield, Clock, AlertCircle, Phone, Mail, Map, CreditCard, Bell, Moon, HelpCircle, Gift, History, ChevronRight, Camera, Save, XCircle, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import 'leaflet/dist/leaflet.css';

// --- Types ---
export type UserRole = 'client' | 'driver';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  role: UserRole;
  isVerified?: boolean;
  photoUrl?: string;
  rating?: number;
  totalRatings?: number;
  phone?: string;
  bio?: string;
  address?: string;
  vehicleModel?: string;
  vehiclePlate?: string;
}

// --- Context ---
interface AuthContextType {
  user: User | null;
  profile: UserProfile | null;
  loading: boolean;
  signOut: () => Promise<void>;
  switchRole: () => Promise<void>;
  openProfile: () => void;
  openSettings: () => void;
  openHistory: () => void;
  openWallet: () => void;
  openPromos: () => void;
  openHelp: () => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};

// --- Components ---
import Login from './components/Login';
import ClientDashboard from './components/ClientDashboard';
import DriverDashboard from './components/DriverDashboard';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [showProfile, setShowProfile] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showWallet, setShowWallet] = useState(false);
  const [showPromos, setShowPromos] = useState(false);
  const [showHelp, setShowHelp] = useState(false);

  useEffect(() => {
    let unsubscribeProfile: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      
      if (unsubscribeProfile) {
        unsubscribeProfile();
        unsubscribeProfile = null;
      }

      if (currentUser) {
        const profileRef = doc(db, 'users', currentUser.uid);
        unsubscribeProfile = onSnapshot(profileRef, (docSnap) => {
          if (docSnap.exists()) {
            setProfile(docSnap.data() as UserProfile);
          } else {
            setProfile(null);
          }
          setLoading(false);
        }, (error) => {
          handleFirestoreError(error, OperationType.GET, `users/${currentUser.uid}`);
          setLoading(false);
        });
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubscribeProfile) unsubscribeProfile();
    };
  }, []);

  const handleSignOut = async () => {
    await auth.signOut();
  };

  const handleSwitchRole = async () => {
    if (!user || !profile) return;
    const newRole: UserRole = profile.role === 'client' ? 'driver' : 'client';
    try {
      await updateDoc(doc(db, 'users', user.uid), { role: newRole });
      setProfile({ ...profile, role: newRole });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#1E293B] flex items-center justify-center">
        <motion.div
          animate={{ rotate: 360 }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
        >
          <Truck className="w-12 h-12 text-[#F97316]" />
        </motion.div>
      </div>
    );
  }

  return (
    <AuthContext.Provider value={{ 
      user, 
      profile, 
      loading, 
      signOut: handleSignOut, 
      switchRole: handleSwitchRole,
      openProfile: () => setShowProfile(true),
      openSettings: () => setShowSettings(true),
      openHistory: () => setShowHistory(true),
      openWallet: () => setShowWallet(true),
      openPromos: () => setShowPromos(true),
      openHelp: () => setShowHelp(true)
    }}>
      <div className="min-h-screen bg-gray-50 text-[#1E293B]">
        {!user ? (
          <Login />
        ) : !profile ? (
          <RoleSelection onComplete={(p) => setProfile(p)} />
        ) : profile.role === 'client' ? (
          <ClientDashboard />
        ) : (
          <DriverDashboard />
        )}
      </div>

      <AnimatePresence>
        {showProfile && (
          <ProfileModal onClose={() => setShowProfile(false)} />
        )}
        {showSettings && (
          <SettingsModal onClose={() => setShowSettings(false)} />
        )}
        {showHistory && (
          <HistoryModal onClose={() => setShowHistory(false)} />
        )}
        {showWallet && (
          <WalletModal onClose={() => setShowWallet(false)} />
        )}
        {showPromos && (
          <PromosModal onClose={() => setShowPromos(false)} />
        )}
        {showHelp && (
          <HelpModal onClose={() => setShowHelp(false)} />
        )}
      </AnimatePresence>
    </AuthContext.Provider>
  );
}

function SettingsModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 bg-[#1E293B]/60 backdrop-blur-sm overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl my-auto"
      >
        <div className="p-8 border-b border-gray-100 flex items-center justify-between">
          <h2 className="text-2xl font-black text-[#1E293B]">Configurações</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-all">
            <XCircle className="w-6 h-6 text-gray-400" />
          </button>
        </div>
        
        <div className="p-8 space-y-6">
          <section>
            <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Preferências</h3>
            <div className="space-y-3">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-500">
                    <Bell className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-bold text-sm">Notificações Push</p>
                    <p className="text-[10px] text-gray-500">Alertas de novos fretes</p>
                  </div>
                </div>
                <div className="w-12 h-6 bg-[#F97316] rounded-full relative cursor-pointer">
                  <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full shadow-sm" />
                </div>
              </div>

              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl opacity-50">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center text-indigo-500">
                    <Moon className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="font-bold text-sm">Modo Escuro</p>
                    <p className="text-[10px] text-gray-500">Em breve</p>
                  </div>
                </div>
                <div className="w-12 h-6 bg-gray-200 rounded-full relative">
                  <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full" />
                </div>
              </div>
            </div>
          </section>

          <section>
            <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Segurança</h3>
            <div className="space-y-3">
              <button className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-all">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-green-50 flex items-center justify-center text-green-500">
                    <Shield className="w-5 h-5" />
                  </div>
                  <p className="font-bold text-sm">Verificação em Duas Etapas</p>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-300" />
              </button>
            </div>
          </section>

          <section>
            <h3 className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-4">Pagamento</h3>
            <div className="space-y-3">
              <button className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-all">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center text-[#F97316]">
                    <CreditCard className="w-5 h-5" />
                  </div>
                  <p className="font-bold text-sm">Métodos de Pagamento</p>
                </div>
                <ChevronRight className="w-4 h-4 text-gray-300" />
              </button>
            </div>
          </section>
        </div>

        <div className="p-8 bg-gray-50/50">
          <button
            onClick={onClose}
            className="w-full py-4 bg-[#1E293B] text-white rounded-2xl font-bold hover:bg-[#2d3d57] transition-all shadow-lg shadow-blue-900/20"
          >
            Salvar Alterações
          </button>
        </div>
      </motion.div>
    </div>
  );
}

function ProfileModal({ onClose }: { onClose: () => void }) {
  const { profile, user } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [formData, setFormData] = useState({
    name: profile?.name || '',
    phone: profile?.phone || '',
    bio: profile?.bio || '',
    address: profile?.address || '',
    vehicleModel: profile?.vehicleModel || '',
    vehiclePlate: profile?.vehiclePlate || '',
    photoUrl: profile?.photoUrl || ''
  });

  if (!profile) return null;

  const handleSave = async () => {
    if (!user) return;
    setLoading(true);
    try {
      await updateDoc(doc(db, 'users', user.uid), formData);
      setIsEditing(false);
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${user.uid}`);
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, photoUrl: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 bg-[#1E293B]/60 backdrop-blur-sm overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col md:flex-row my-auto"
      >
        {/* Left Side: Profile Overview */}
        <div className="md:w-1/3 bg-[#1E293B] p-8 text-white flex flex-col items-center text-center shrink-0">
          <div className="relative mb-6">
            <img
              src={formData.photoUrl || profile.photoUrl || `https://picsum.photos/seed/${profile.uid}/200/200`}
              alt={profile.name}
              className="w-32 h-32 rounded-3xl object-cover border-4 border-white/10 shadow-2xl"
            />
            {isEditing && (
              <>
                <input
                  type="file"
                  ref={fileInputRef}
                  onChange={handleFileChange}
                  className="hidden"
                  accept="image/*"
                />
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  className="absolute -bottom-2 -right-2 p-3 bg-[#F97316] rounded-2xl shadow-lg hover:scale-110 transition-all"
                >
                  <Camera className="w-5 h-5 text-white" />
                </button>
              </>
            )}
          </div>
          
          <h2 className="text-2xl font-black mb-1">{profile.name}</h2>
          <p className="text-gray-400 text-sm mb-6">{profile.email}</p>
          
          <div className="w-full space-y-3">
            <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
              <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Avaliação</p>
              <div className="flex items-center justify-center gap-1 font-bold text-xl">
                <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                {profile.rating?.toFixed(1)}
              </div>
            </div>
            <div className="p-4 bg-white/5 rounded-2xl border border-white/10">
              <p className="text-[10px] font-black text-gray-500 uppercase tracking-widest mb-1">Membro desde</p>
              <p className="font-bold text-lg">Março 2024</p>
            </div>
          </div>

          <div className="mt-auto pt-8">
            <div className={`px-4 py-2 rounded-full text-xs font-bold border flex items-center gap-2 ${
              profile.isVerified ? 'bg-green-500/10 text-green-400 border-green-500/20' : 'bg-yellow-500/10 text-yellow-400 border-yellow-500/20'
            }`}>
              <Shield className="w-4 h-4" />
              {profile.isVerified ? 'CONTA VERIFICADA' : 'AGUARDANDO VERIFICAÇÃO'}
            </div>
          </div>
        </div>

        {/* Right Side: Form/Details */}
        <div className="md:w-2/3 p-8">
          <div className="flex items-center justify-between mb-8">
            <h3 className="text-xl font-black text-[#1E293B]">Informações Pessoais</h3>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-all">
              <XCircle className="w-6 h-6 text-gray-400" />
            </button>
          </div>

          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Nome Completo</label>
                <div className="relative">
                  <UserIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    disabled={!isEditing}
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full pl-12 pr-4 py-3 bg-gray-50 border-2 border-transparent focus:border-[#F97316] focus:bg-white rounded-2xl transition-all outline-none disabled:opacity-70"
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Telefone</label>
                <div className="relative">
                  <Phone className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="tel"
                    disabled={!isEditing}
                    placeholder="(00) 00000-0000"
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    className="w-full pl-12 pr-4 py-3 bg-gray-50 border-2 border-transparent focus:border-[#F97316] focus:bg-white rounded-2xl transition-all outline-none disabled:opacity-70"
                  />
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Bio / Descrição</label>
              <textarea
                disabled={!isEditing}
                rows={3}
                placeholder="Conte um pouco sobre você..."
                value={formData.bio}
                onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                className="w-full px-4 py-3 bg-gray-50 border-2 border-transparent focus:border-[#F97316] focus:bg-white rounded-2xl transition-all outline-none resize-none disabled:opacity-70"
              />
            </div>

            <div className="space-y-2">
              <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Endereço Principal</label>
              <div className="relative">
                <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  disabled={!isEditing}
                  placeholder="Rua, Número, Bairro, Cidade - UF"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="w-full pl-12 pr-4 py-3 bg-gray-50 border-2 border-transparent focus:border-[#F97316] focus:bg-white rounded-2xl transition-all outline-none disabled:opacity-70"
                />
              </div>
            </div>

            {profile.role === 'driver' && (
              <div className="pt-6 border-t border-gray-100">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="text-sm font-black text-[#1E293B] flex items-center gap-2">
                    <Truck className="w-4 h-4 text-[#F97316]" />
                    Dados do Veículo
                  </h4>
                  {!isEditing && (
                    <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                      {formData.vehicleModel ? 'Cadastrado' : 'Não cadastrado'}
                    </span>
                  )}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Modelo do Veículo</label>
                    <input
                      type="text"
                      disabled={!isEditing}
                      placeholder="Ex: Mercedes-Benz Sprinter"
                      value={formData.vehicleModel}
                      onChange={(e) => setFormData({ ...formData, vehicleModel: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-50 border-2 border-transparent focus:border-[#F97316] focus:bg-white rounded-2xl transition-all outline-none disabled:opacity-70"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-black text-gray-400 uppercase tracking-widest">Placa</label>
                    <input
                      type="text"
                      disabled={!isEditing}
                      placeholder="ABC-1234"
                      value={formData.vehiclePlate}
                      onChange={(e) => setFormData({ ...formData, vehiclePlate: e.target.value })}
                      className="w-full px-4 py-3 bg-gray-50 border-2 border-transparent focus:border-[#F97316] focus:bg-white rounded-2xl transition-all outline-none disabled:opacity-70"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>

          <div className="mt-10 flex gap-4">
            {!isEditing ? (
              <button
                onClick={() => setIsEditing(true)}
                className="flex-1 py-4 bg-[#1E293B] text-white rounded-2xl font-bold hover:bg-[#2d3d57] transition-all shadow-lg shadow-blue-900/20"
              >
                Editar Perfil
              </button>
            ) : (
              <>
                <button
                  onClick={() => setIsEditing(false)}
                  className="flex-1 py-4 bg-gray-100 text-gray-600 rounded-2xl font-bold hover:bg-gray-200 transition-all"
                >
                  Cancelar
                </button>
                <button
                  onClick={handleSave}
                  disabled={loading}
                  className="flex-[2] py-4 bg-[#F97316] text-white rounded-2xl font-bold hover:bg-[#fa8533] transition-all shadow-lg shadow-orange-900/20 flex items-center justify-center gap-2"
                >
                  <Save className="w-5 h-5" />
                  {loading ? 'Salvando...' : 'Salvar Alterações'}
                </button>
              </>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function HistoryModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 bg-[#1E293B]/60 backdrop-blur-sm overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl my-auto"
      >
        <div className="p-8 border-b border-gray-100 flex items-center justify-between">
          <h2 className="text-2xl font-black text-[#1E293B]">Histórico de Fretes</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-all">
            <XCircle className="w-6 h-6 text-gray-400" />
          </button>
        </div>
        <div className="p-8">
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <History className="w-16 h-16 text-gray-200 mb-4" />
            <p className="text-gray-500 font-medium">Você ainda não possui um histórico de viagens.</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function WalletModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 bg-[#1E293B]/60 backdrop-blur-sm overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl my-auto"
      >
        <div className="p-8 border-b border-gray-100 flex items-center justify-between">
          <h2 className="text-2xl font-black text-[#1E293B]">Minha Carteira</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-all">
            <XCircle className="w-6 h-6 text-gray-400" />
          </button>
        </div>
        <div className="p-8 space-y-6">
          <div className="p-6 bg-[#1E293B] rounded-3xl text-white">
            <p className="text-xs font-black text-gray-400 uppercase tracking-widest mb-1">Saldo Disponível</p>
            <h3 className="text-3xl font-black">R$ 0,00</h3>
          </div>
          <button className="w-full py-4 bg-[#F97316] text-white rounded-2xl font-bold hover:bg-[#fa8533] transition-all shadow-lg shadow-orange-900/20">
            Adicionar Saldo
          </button>
        </div>
      </motion.div>
    </div>
  );
}

function PromosModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 bg-[#1E293B]/60 backdrop-blur-sm overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl my-auto"
      >
        <div className="p-8 border-b border-gray-100 flex items-center justify-between">
          <h2 className="text-2xl font-black text-[#1E293B]">Promoções</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-all">
            <XCircle className="w-6 h-6 text-gray-400" />
          </button>
        </div>
        <div className="p-8 space-y-4">
          <div className="p-6 bg-orange-50 border-2 border-dashed border-orange-200 rounded-3xl text-center">
            <Gift className="w-12 h-12 text-[#F97316] mx-auto mb-4" />
            <p className="font-bold text-[#1E293B]">Nenhum cupom disponível</p>
            <p className="text-xs text-gray-500 mt-1">Fique de olho em nossas redes sociais!</p>
          </div>
        </div>
      </motion.div>
    </div>
  );
}

function HelpModal({ onClose }: { onClose: () => void }) {
  return (
    <div className="fixed inset-0 z-[2000] flex items-center justify-center p-4 bg-[#1E293B]/60 backdrop-blur-sm overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 20 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        exit={{ opacity: 0, scale: 0.95, y: 20 }}
        className="bg-white rounded-3xl w-full max-w-md overflow-hidden shadow-2xl my-auto"
      >
        <div className="p-8 border-b border-gray-100 flex items-center justify-between">
          <h2 className="text-2xl font-black text-[#1E293B]">Central de Ajuda</h2>
          <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-all">
            <XCircle className="w-6 h-6 text-gray-400" />
          </button>
        </div>
        <div className="p-8 space-y-4">
          <button className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-all">
            <div className="flex items-center gap-3">
              <MessageSquare className="w-5 h-5 text-blue-500" />
              <p className="font-bold text-sm">Chat com Suporte</p>
            </div>
            <ChevronRight className="w-4 h-4 text-gray-300" />
          </button>
          <button className="w-full flex items-center justify-between p-4 bg-gray-50 rounded-2xl hover:bg-gray-100 transition-all">
            <div className="flex items-center gap-3">
              <Phone className="w-5 h-5 text-green-500" />
              <p className="font-bold text-sm">Ligar para nós</p>
            </div>
            <ChevronRight className="w-4 h-4 text-gray-300" />
          </button>
        </div>
      </motion.div>
    </div>
  );
}

function RoleSelection({ onComplete }: { onComplete: (p: UserProfile) => void }) {
  const { user } = useAuth();
  const [role, setRole] = useState<UserRole | null>(null);
  const [saving, setSaving] = useState(false);

  const handleSave = async () => {
    if (!user || !role) return;
    setSaving(true);
    const newProfile: UserProfile = {
      uid: user.uid,
      name: user.displayName || 'Usuário',
      email: user.email || '',
      role: role,
      isVerified: false,
      photoUrl: user.photoURL || '',
      rating: 5,
      totalRatings: 0
    };

    try {
      await setDoc(doc(db, 'users', user.uid), newProfile);
      onComplete(newProfile);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, `users/${user.uid}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4">
      <div className="max-w-md w-full bg-white rounded-2xl shadow-xl p-8">
        <h2 className="text-2xl font-bold text-center mb-8">Como você quer usar o FreightGo?</h2>
        <div className="grid grid-cols-2 gap-4 mb-8">
          <button
            onClick={() => setRole('client')}
            className={`p-6 rounded-xl border-2 transition-all flex flex-col items-center gap-3 ${
              role === 'client' ? 'border-[#F97316] bg-orange-50' : 'border-gray-100 hover:border-gray-200'
            }`}
          >
            <UserIcon className={`w-10 h-10 ${role === 'client' ? 'text-[#F97316]' : 'text-gray-400'}`} />
            <span className="font-semibold">Cliente</span>
          </button>
          <button
            onClick={() => setRole('driver')}
            className={`p-6 rounded-xl border-2 transition-all flex flex-col items-center gap-3 ${
              role === 'driver' ? 'border-[#F97316] bg-orange-50' : 'border-gray-100 hover:border-gray-200'
            }`}
          >
            <Truck className={`w-10 h-10 ${role === 'driver' ? 'text-[#F97316]' : 'text-gray-400'}`} />
            <span className="font-semibold">Motorista</span>
          </button>
        </div>
        <button
          disabled={!role || saving}
          onClick={handleSave}
          className="w-full py-4 bg-[#1E293B] text-white rounded-xl font-bold hover:bg-[#2d3d57] disabled:opacity-50 transition-all"
        >
          {saving ? 'Salvando...' : 'Começar Agora'}
        </button>
      </div>
    </div>
  );
}
