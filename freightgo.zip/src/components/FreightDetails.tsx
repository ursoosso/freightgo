import React, { useEffect, useState } from 'react';
import { db, doc, onSnapshot, handleFirestoreError, OperationType, updateDoc, getDoc } from '../firebase';
import { XCircle, MapPin, Navigation, Truck, User, Phone, Shield, Clock, CheckCircle, AlertCircle, ExternalLink, Star, MessageSquare } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MapContainer, TileLayer, Marker, Polyline, useMap } from 'react-leaflet';
import L from 'leaflet';
import Chat from './Chat';
import { useAuth } from '../App';

// Fix Leaflet marker icon issue
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

function MapBoundsUpdater({ coords }: { coords: [number, number][] }) {
  const map = useMap();
  useEffect(() => {
    // Force a resize check when coordinates or map changes
    const timer = setTimeout(() => {
      map.invalidateSize();
      if (coords.length > 0) {
        try {
          const bounds = L.latLngBounds(coords);
          map.fitBounds(bounds, { padding: [50, 50] });
        } catch (e) {
          console.error("Error fitting bounds:", e);
        }
      }
    }, 250);
    return () => clearTimeout(timer);
  }, [coords, map]);
  return null;
}

interface FreightDetailsProps {
  freightId: string;
  onClose: () => void;
}

export default function FreightDetails({ freightId, onClose }: FreightDetailsProps) {
  const { profile } = useAuth();
  const [freight, setFreight] = useState<any>(null);
  const [driver, setDriver] = useState<any>(null);
  const [client, setClient] = useState<any>(null);
  const [driverLocation, setDriverLocation] = useState<any>(null);
  const [routeCoords, setRouteCoords] = useState<[number, number][]>([]);
  const [loading, setLoading] = useState(true);
  const [showChat, setShowChat] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const [rating, setRating] = useState(0);
  const [hoverRating, setHoverRating] = useState(0);
  const [submittingRating, setSubmittingRating] = useState(false);

  useEffect(() => {
    const fetchRoute = async (origin: any, dest: any) => {
      try {
        const response = await fetch(
          `https://router.project-osrm.org/route/v1/driving/${origin.lng},${origin.lat};${dest.lng},${dest.lat}?overview=full&geometries=geojson`
        );
        const data = await response.json();
        if (data.routes && data.routes[0]) {
          const coords = data.routes[0].geometry.coordinates.map((c: any) => [c[1], c[0]] as [number, number]);
          setRouteCoords(coords);
        }
      } catch (error) {
        console.error("Error fetching route:", error);
        // Fallback to straight line if OSRM fails
        setRouteCoords([[origin.lat, origin.lng], [dest.lat, dest.lng]]);
      }
    };

    const unsubscribe = onSnapshot(doc(db, 'freights', freightId), (snapshot) => {
      if (snapshot.exists()) {
        const data: any = { id: snapshot.id, ...snapshot.data() };
        setFreight(data);
        
        if (data.origin && data.destination) {
          fetchRoute(data.origin, data.destination);
        }
        
        if (data.driverId) {
          onSnapshot(doc(db, 'users', data.driverId), (driverSnap) => {
            if (driverSnap.exists()) {
              setDriver(driverSnap.data());
            }
          });

          // Listen to driver location if in transit
          if (data.status === 'in-transit') {
            onSnapshot(doc(db, 'locations', data.driverId), (locSnap) => {
              if (locSnap.exists()) {
                setDriverLocation(locSnap.data());
              }
            });
          } else {
            setDriverLocation(null);
          }
        }
        if (data.clientId) {
          onSnapshot(doc(db, 'users', data.clientId), (clientSnap) => {
            if (clientSnap.exists()) {
              setClient(clientSnap.data());
            }
          });
        }
      }
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, `freights/${freightId}`);
    });

    return () => unsubscribe();
  }, [freightId]);

  const handleCancel = async () => {
    if (!profile || !freight) return;
    
    const isClient = profile.role === 'client';
    const isDriver = profile.role === 'driver';
    
    let confirmMsg = '';
    if (isClient) {
      confirmMsg = 'Tem certeza que deseja cancelar este frete? Esta ação não pode ser desfeita.';
    } else if (isDriver) {
      confirmMsg = 'Tem certeza que deseja desistir deste frete? Ele voltará a ficar disponível para outros motoristas.';
    }

    setCancelling(true);
    try {
      if (isClient) {
        await updateDoc(doc(db, 'freights', freightId), {
          status: 'cancelled',
          cancelledAt: new Date().toISOString()
        });
      } else if (isDriver) {
        await updateDoc(doc(db, 'freights', freightId), {
          status: 'pending',
          driverId: null,
          acceptedAt: null
        });
      }
      onClose();
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `freights/${freightId}`);
    } finally {
      setCancelling(false);
    }
  };

  const handleRate = async () => {
    if (!profile || !freight || rating === 0) return;
    
    setSubmittingRating(true);
    try {
      const isClient = profile.role === 'client';
      const targetId = isClient ? freight.driverId : freight.clientId;
      const targetSnap = await getDoc(doc(db, 'users', targetId));
      
      if (targetSnap.exists()) {
        const targetData = targetSnap.data();
        const currentRating = targetData.rating || 5;
        const totalRatings = targetData.totalRatings || 0;
        
        const newTotalRatings = totalRatings + 1;
        const newRating = ((currentRating * totalRatings) + rating) / newTotalRatings;
        
        await updateDoc(doc(db, 'users', targetId), {
          rating: newRating,
          totalRatings: newTotalRatings
        });
        
        await updateDoc(doc(db, 'freights', freightId), {
          [isClient ? 'clientRated' : 'driverRated']: true
        });
      }
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${freight.driverId}`);
    } finally {
      setSubmittingRating(false);
    }
  };

  if (loading) return null;
  if (!freight) return null;

  const statusSteps = ['pending', 'accepted', 'in-transit', 'delivered'];
  const currentStepIndex = statusSteps.indexOf(freight.status);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1E293B]/80 backdrop-blur-md">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white rounded-3xl w-full max-w-4xl overflow-hidden shadow-2xl flex flex-col lg:flex-row max-h-[90vh]"
      >
        {/* Left Side: Map & Status */}
        <div className="lg:w-1/2 bg-gray-100 relative h-[400px] lg:h-[600px] border-r border-gray-100 overflow-hidden">
          <MapContainer 
            key={freight.id}
            center={[freight.origin.lat, freight.origin.lng]} 
            zoom={12} 
            style={{ height: '100%', width: '100%', zIndex: 1 }}
          >
            <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
            <MapBoundsUpdater coords={routeCoords.length > 0 ? routeCoords : [[freight.origin.lat, freight.origin.lng], [freight.destination.lat, freight.destination.lng]]} />
            <Marker position={[freight.origin.lat, freight.origin.lng]} icon={L.divIcon({
              className: 'custom-div-icon',
              html: `<div style="background-color: #10B981; width: 16px; height: 16px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 15px rgba(16, 185, 129, 0.6);"></div>`,
              iconSize: [16, 16],
              iconAnchor: [8, 8]
            })} />
            <Marker position={[freight.destination.lat, freight.destination.lng]} icon={L.divIcon({
              className: 'custom-div-icon',
              html: `<div style="background-color: #EF4444; width: 16px; height: 16px; border-radius: 50%; border: 3px solid white; box-shadow: 0 0 15px rgba(239, 68, 68, 0.6);"></div>`,
              iconSize: [16, 16],
              iconAnchor: [8, 8]
            })} />
            {driverLocation && (
              <Marker 
                position={[driverLocation.lat, driverLocation.lng]} 
                icon={L.divIcon({
                  className: 'custom-div-icon',
                  html: `<div style="background-color: #F97316; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white; box-shadow: 0 0 10px rgba(249, 115, 22, 0.5);"></div>`,
                  iconSize: [12, 12],
                  iconAnchor: [6, 6]
                })}
              />
            )}
            <Polyline 
              positions={routeCoords.length > 0 ? routeCoords : [
                [freight.origin.lat, freight.origin.lng],
                [freight.destination.lat, freight.destination.lng]
              ]} 
              color="#F97316"
              weight={4}
              opacity={0.8}
            />
          </MapContainer>

          <div className="absolute top-4 left-4 z-[1000] bg-white/90 backdrop-blur px-4 py-2 rounded-full shadow-sm border border-white/20 text-xs font-bold flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
            RASTREAMENTO EM TEMPO REAL
          </div>
        </div>

        {/* Right Side: Details */}
        <div className="lg:w-1/2 p-8 overflow-y-auto">
          <div className="flex items-center justify-between mb-8">
            <div>
              <div className="flex items-center gap-3">
                <h2 className="text-2xl font-black text-[#1E293B]">Detalhes do Frete</h2>
                <motion.span
                  key={freight.status}
                  initial={{ opacity: 0, scale: 0.8 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-wider ${
                    freight.status === 'delivered' ? 'bg-green-100 text-green-600' :
                    freight.status === 'cancelled' ? 'bg-red-100 text-red-600' :
                    'bg-orange-100 text-[#F97316]'
                  }`}
                >
                  {freight.status === 'pending' ? 'Pendente' : 
                   freight.status === 'accepted' ? 'Aceito' : 
                   freight.status === 'in-transit' ? 'Em Rota' : 
                   freight.status === 'delivered' ? 'Entregue' : 'Cancelado'}
                </motion.span>
                {freight.isPremium && (
                  <motion.span
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    className="px-3 py-1 bg-amber-400 text-white rounded-full text-[10px] font-black uppercase tracking-wider flex items-center gap-1 shadow-sm"
                  >
                    <Star className="w-3 h-3 fill-current" />
                    Premium
                  </motion.span>
                )}
              </div>
              <p className="text-sm text-gray-400 font-medium">ID: #{freight.id.slice(0, 8).toUpperCase()}</p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-all">
              <XCircle className="w-6 h-6 text-gray-400" />
            </button>
          </div>

          {/* Status Stepper */}
          <div className="flex justify-between mb-10 relative px-2">
            <div className="absolute top-1/2 left-0 w-full h-0.5 bg-gray-100 -translate-y-1/2 z-0" />
            <motion.div 
              className="absolute top-1/2 left-0 h-0.5 bg-[#F97316] -translate-y-1/2 z-0" 
              initial={{ width: 0 }}
              animate={{ width: `${(currentStepIndex / (statusSteps.length - 1)) * 100}%` }}
              transition={{ duration: 0.8, ease: "easeInOut" }}
            />
            {statusSteps.map((step, i) => {
              const isActive = i <= currentStepIndex;
              const isCurrent = i === currentStepIndex;
              return (
                <div key={step} className="relative z-10 flex flex-col items-center gap-2">
                  <motion.div 
                    initial={false}
                    animate={{ 
                      scale: isCurrent ? 1.1 : 1,
                      backgroundColor: isActive ? '#F97316' : '#FFFFFF',
                      borderColor: isActive ? '#FFEDD5' : '#F3F4F6',
                      color: isActive ? '#FFFFFF' : '#D1D5DB'
                    }}
                    className={`w-8 h-8 rounded-full flex items-center justify-center border-4 transition-colors ${
                      isCurrent ? 'ring-4 ring-orange-50' : ''
                    }`}
                  >
                    {isActive ? (
                      <motion.div
                        initial={{ scale: 0 }}
                        animate={{ scale: 1 }}
                        transition={{ type: "spring", stiffness: 300, damping: 20 }}
                      >
                        <CheckCircle className="w-4 h-4" />
                      </motion.div>
                    ) : (
                      <div className="w-2 h-2 rounded-full bg-current" />
                    )}
                  </motion.div>
                  <motion.span 
                    animate={{ 
                      opacity: isActive ? 1 : 0.4,
                      scale: isCurrent ? 1.05 : 1,
                      color: isActive ? '#F97316' : '#D1D5DB'
                    }}
                    className="text-[10px] font-bold uppercase tracking-wider"
                  >
                    {step === 'pending' ? 'Pendente' : step === 'accepted' ? 'Aceito' : step === 'in-transit' ? 'Em Rota' : 'Entregue'}
                  </motion.span>
                </div>
              );
            })}
          </div>

          <div className="space-y-8">
            {/* Route Info */}
            <div className="grid grid-cols-1 gap-6">
              <div className="flex gap-4">
                <div className="flex flex-col items-center gap-1">
                  <div className="w-3 h-3 rounded-full bg-blue-500" />
                  <div className="w-0.5 flex-1 bg-gray-100" />
                  <div className="w-3 h-3 rounded-full bg-[#F97316]" />
                </div>
                <div className="flex-1 space-y-6">
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Origem</p>
                    <p className="text-sm font-bold text-gray-700">{freight.origin.address}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Destino</p>
                    <p className="text-sm font-bold text-gray-700">{freight.destination.address}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Driver Info (if any) */}
            {driver && (
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Motorista Responsável</p>
                <div className="flex items-center gap-4">
                  <img src={driver.photoUrl || `https://picsum.photos/seed/${driver.uid}/100/100`} className="w-12 h-12 rounded-full object-cover" alt="" />
                  <div className="flex-1">
                    <p className="font-bold text-[#1E293B]">{driver.name}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                      <span>{driver.rating?.toFixed(1)}</span>
                      <span className="mx-1">•</span>
                      <span className="flex items-center gap-1"><Shield className="w-3 h-3" /> Verificado</span>
                    </div>
                    {(driver.vehicleModel || driver.vehiclePlate) && (
                      <div className="mt-1 flex items-center gap-2 text-[10px] font-bold text-gray-400 uppercase">
                        <Truck className="w-3 h-3" />
                        <span>{driver.vehicleModel || 'Veículo não informado'}</span>
                        {driver.vehiclePlate && (
                          <>
                            <span className="mx-1">•</span>
                            <span className="bg-gray-200 px-1.5 py-0.5 rounded text-[#1E293B]">{driver.vehiclePlate}</span>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => setShowChat(!showChat)}
                      className={`p-3 rounded-xl shadow-sm border border-gray-100 transition-all ${
                        showChat ? 'bg-[#F97316] text-white' : 'bg-white text-[#F97316] hover:bg-orange-50'
                      }`}
                    >
                      <MessageSquare className="w-5 h-5" />
                    </button>
                    <button className="p-3 bg-white rounded-xl shadow-sm border border-gray-100 text-[#F97316] hover:bg-orange-50 transition-all">
                      <Phone className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Client Info (if driver is viewing) */}
            {client && profile?.role === 'driver' && (
              <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-3">Solicitante (Cliente)</p>
                <div className="flex items-center gap-4">
                  <img src={client.photoUrl || `https://picsum.photos/seed/${client.uid}/100/100`} className="w-12 h-12 rounded-full object-cover" alt="" />
                  <div className="flex-1">
                    <p className="font-bold text-[#1E293B]">{client.name}</p>
                    <div className="flex items-center gap-2 text-xs text-gray-500">
                      <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                      <span>{client.rating?.toFixed(1) || '5.0'}</span>
                      <span className="mx-1">•</span>
                      <span>Cliente FreightGo</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <button 
                      onClick={() => setShowChat(!showChat)}
                      className={`p-3 rounded-xl shadow-sm border border-gray-100 transition-all ${
                        showChat ? 'bg-[#F97316] text-white' : 'bg-white text-[#F97316] hover:bg-orange-50'
                      }`}
                    >
                      <MessageSquare className="w-5 h-5" />
                    </button>
                    <button className="p-3 bg-white rounded-xl shadow-sm border border-gray-100 text-[#F97316] hover:bg-orange-50 transition-all">
                      <Phone className="w-5 h-5" />
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Chat Integration */}
            <AnimatePresence>
              {showChat && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  exit={{ opacity: 0, height: 0 }}
                  className="overflow-hidden"
                >
                  <Chat 
                    freightId={freight.id} 
                    otherPartyName={profile?.role === 'client' ? driver?.name : client?.name} 
                  />
                </motion.div>
              )}
            </AnimatePresence>

            {/* Rating Section */}
            {freight.status === 'delivered' && (
              <div className="p-6 bg-orange-50 rounded-3xl border border-orange-100">
                {((profile?.role === 'client' && !freight.clientRated) || 
                  (profile?.role === 'driver' && !freight.driverRated)) ? (
                  <div className="text-center space-y-4">
                    <h3 className="font-bold text-[#1E293B]">Como foi sua experiência?</h3>
                    <p className="text-xs text-gray-500">Sua avaliação ajuda a manter a qualidade da comunidade.</p>
                    <div className="flex justify-center gap-2">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          onMouseEnter={() => setHoverRating(star)}
                          onMouseLeave={() => setHoverRating(0)}
                          onClick={() => setRating(star)}
                          className="transition-all transform hover:scale-110"
                        >
                          <Star 
                            className={`w-8 h-8 ${
                              star <= (hoverRating || rating) 
                                ? 'text-yellow-400 fill-yellow-400' 
                                : 'text-gray-300'
                            }`} 
                          />
                        </button>
                      ))}
                    </div>
                    <button
                      onClick={handleRate}
                      disabled={rating === 0 || submittingRating}
                      className="w-full py-3 bg-[#F97316] text-white rounded-xl font-bold hover:bg-[#fa8533] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      {submittingRating ? 'Enviando...' : 'Enviar Avaliação'}
                    </button>
                  </div>
                ) : (
                  <div className="flex items-center justify-center gap-3 text-green-600 font-bold">
                    <CheckCircle className="w-5 h-5" />
                    <span>Avaliação enviada! Obrigado.</span>
                  </div>
                )}
              </div>
            )}

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-4">
              <div className="p-4 bg-blue-50/50 rounded-2xl border border-blue-100/50">
                <p className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-1">Preço Total</p>
                <p className="text-xl font-black text-[#1E293B]">R$ {freight.price.toFixed(2)}</p>
              </div>
              <div className="p-4 bg-orange-50/50 rounded-2xl border border-orange-100/50">
                <p className="text-[10px] font-black text-orange-400 uppercase tracking-widest mb-1">Distância</p>
                <p className="text-xl font-black text-[#1E293B]">{freight.distance.toFixed(1)} km</p>
              </div>
            </div>

            <div className="flex flex-col gap-3">
              <button className="w-full py-4 bg-[#1E293B] text-white rounded-2xl font-bold hover:bg-[#2d3d57] transition-all flex items-center justify-center gap-2">
                <ExternalLink className="w-5 h-5" />
                Abrir no Google Maps
              </button>

              {((profile?.role === 'client' && (freight.status === 'pending' || freight.status === 'accepted')) ||
                (profile?.role === 'driver' && freight.status === 'accepted')) && (
                <button 
                  onClick={handleCancel}
                  disabled={cancelling}
                  className="w-full py-4 bg-red-50 text-red-500 rounded-2xl font-bold hover:bg-red-100 transition-all flex items-center justify-center gap-2"
                >
                  <XCircle className="w-5 h-5" />
                  {profile?.role === 'client' ? 'Cancelar Frete' : 'Desistir do Frete'}
                </button>
              )}
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
}
