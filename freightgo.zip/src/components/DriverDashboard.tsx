import React, { useState, useEffect } from 'react';
import { useAuth, UserProfile } from '../App';
import { db, collection, query, where, onSnapshot, orderBy, limit, handleFirestoreError, OperationType, updateDoc, doc, setDoc } from '../firebase';
import { Truck, MapPin, Navigation, Package, Star, LogOut, Clock, CheckCircle, XCircle, AlertCircle, ChevronRight, Search, ShieldCheck, DollarSign, User } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import FreightDetails from './FreightDetails';
import UserMenu from './UserMenu';

// Fix Leaflet marker icon issue
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

export default function DriverDashboard() {
  const { profile, signOut, switchRole, openHelp, openSettings, openProfile } = useAuth();
  const [availableFreights, setAvailableFreights] = useState<any[]>([]);
  const [myFreights, setMyFreights] = useState<any[]>([]);
  const [selectedFreightId, setSelectedFreightId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'available' | 'my'>('available');
  const [currentLocation, setCurrentLocation] = useState<[number, number] | null>(null);

  useEffect(() => {
    if (!profile) return;

    // Fetch available freights (pending)
    const qAvailable = query(
      collection(db, 'freights'),
      where('status', '==', 'pending'),
      orderBy('createdAt', 'desc')
    );

    const unsubscribeAvailable = onSnapshot(qAvailable, (snapshot) => {
      setAvailableFreights(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'freights');
    });

    // Fetch driver's accepted freights
    const qMy = query(
      collection(db, 'freights'),
      where('driverId', '==', profile.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribeMy = onSnapshot(qMy, (snapshot) => {
      setMyFreights(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'freights');
    });

    return () => {
      unsubscribeAvailable();
      unsubscribeMy();
    };
  }, [profile]);

  // Real-time location tracking for active freights
  useEffect(() => {
    if (!profile) return;
    
    const hasActiveFreight = myFreights.some(f => f.status === 'in-transit');
    let watchId: number;

    if (navigator.geolocation) {
      watchId = navigator.geolocation.watchPosition(
        async (position) => {
          const coords: [number, number] = [position.coords.latitude, position.coords.longitude];
          setCurrentLocation(coords);
          
          if (hasActiveFreight) {
            try {
              await setDoc(doc(db, 'locations', profile.uid), {
                lat: position.coords.latitude,
                lng: position.coords.longitude,
                updatedAt: new Date().toISOString(),
                driverName: profile.name
              });
            } catch (error) {
              console.error("Error updating location:", error);
            }
          }
        },
        (error) => console.error("Geolocation error:", error),
        { enableHighAccuracy: true }
      );
    }

    return () => {
      if (watchId) navigator.geolocation.clearWatch(watchId);
    };
  }, [profile, myFreights]);

  const earnings = myFreights
    .filter(f => f.status === 'delivered')
    .reduce((acc, f) => acc + (f.price || 0), 0);

  const completedCount = myFreights.filter(f => f.status === 'delivered').length;

  const activeFreight = myFreights.find(f => f.status === 'in-transit');

  function MapUpdater({ center, zoom }: { center: [number, number], zoom: number }) {
    const map = useMapEvents({});
    useEffect(() => {
      map.setView(center, zoom);
    }, [center, zoom, map]);
    return null;
  }

  const handleAcceptFreight = async (freightId: string) => {
    if (!profile) return;
    try {
      await updateDoc(doc(db, 'freights', freightId), {
        status: 'accepted',
        driverId: profile.uid,
        acceptedAt: new Date().toISOString()
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `freights/${freightId}`);
    }
  };

  const handleCancelFreight = async (freightId: string) => {
    try {
      await updateDoc(doc(db, 'freights', freightId), {
        status: 'pending',
        driverId: null
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `freights/${freightId}`);
    }
  };

  const handleUpdateStatus = async (freightId: string, newStatus: string) => {
    try {
      await updateDoc(doc(db, 'freights', freightId), {
        status: newStatus
      });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `freights/${freightId}`);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Header */}
      <header className="flex items-center justify-between mb-12">
        <div className="flex items-center gap-3">
          <Truck className="w-10 h-10 text-[#F97316]" />
          <h1 className="text-3xl font-black tracking-tighter text-[#1E293B]">FreightGo</h1>
        </div>
        <div className="flex items-center gap-6">
          {profile?.vehicleModel && (
            <div className="hidden md:flex items-center gap-2 bg-orange-50 px-4 py-2 rounded-full border border-orange-100">
              <Truck className="w-4 h-4 text-[#F97316]" />
              <span className="text-xs font-bold text-[#F97316] uppercase tracking-wider">
                {profile.vehicleModel} • {profile.vehiclePlate || 'S/ Placa'}
              </span>
            </div>
          )}
          <UserMenu />
        </div>
      </header>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Sidebar: Stats & Verification */}
        <div className="space-y-8 order-2 lg:order-1">
          <div className="bg-[#1E293B] rounded-3xl p-8 text-white shadow-2xl relative overflow-hidden">
            <div className="absolute top-0 right-0 w-32 h-32 bg-[#F97316] opacity-10 rounded-full -mr-16 -mt-16" />
            <h3 className="text-lg font-bold mb-8 flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-[#F97316]" />
              </div>
              Ganhos do Mês
            </h3>
            <div className="space-y-6">
              <div>
                <p className="text-gray-400 text-xs font-bold uppercase tracking-widest mb-1">Total Recebido</p>
                <p className="text-4xl font-black tracking-tighter">R$ {earnings.toFixed(2)}</p>
              </div>
              <div className="pt-6 border-t border-white/10 flex justify-between items-center">
                <div>
                  <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mb-1">Entregas</p>
                  <p className="text-xl font-bold">{completedCount}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-gray-400 font-bold uppercase tracking-widest mb-1">Avaliação</p>
                  <div className="flex items-center gap-1 text-[#F97316]">
                    <Star className="w-4 h-4 fill-current" />
                    <span className="font-bold text-white">{profile?.rating || '5.0'}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <button 
              onClick={openSettings}
              className="p-4 bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all flex flex-col items-center gap-2 group"
            >
              <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600 group-hover:scale-110 transition-transform">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-gray-600">Seguro</span>
            </button>
            <button 
              onClick={openHelp}
              className="p-4 bg-white rounded-2xl border border-gray-100 shadow-sm hover:shadow-md transition-all flex flex-col items-center gap-2 group"
            >
              <div className="w-10 h-10 rounded-xl bg-orange-50 flex items-center justify-center text-[#F97316] group-hover:scale-110 transition-transform">
                <AlertCircle className="w-5 h-5" />
              </div>
              <span className="text-xs font-bold text-gray-600">Suporte</span>
            </button>
          </div>

          <button 
            onClick={() => alert('🚨 SOS Ativado! Nossa central de segurança foi notificada e está rastreando sua localização em tempo real.')}
            className="w-full py-4 bg-red-50 text-red-600 rounded-2xl font-black uppercase tracking-widest text-sm hover:bg-red-100 transition-all flex items-center justify-center gap-3 border-2 border-red-100"
          >
            <div className="w-2 h-2 rounded-full bg-red-600 animate-ping" />
            Botão de SOS
          </button>

          {!profile?.isVerified && (
            <div className="bg-orange-50 rounded-3xl p-8 border border-orange-100 relative overflow-hidden">
              <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-[#F97316] opacity-5 rounded-full" />
              <div className="flex items-center gap-3 mb-4">
                <ShieldCheck className="w-6 h-6 text-[#F97316]" />
                <h3 className="font-bold text-[#1E293B]">Verifique sua conta</h3>
              </div>
              <p className="text-sm text-gray-600 mb-6 leading-relaxed">Para aceitar fretes de alto valor e ter prioridade, precisamos validar seus documentos.</p>
              <button 
                onClick={openProfile}
                className="w-full py-4 bg-[#F97316] text-white rounded-2xl font-bold hover:bg-[#fa8533] transition-all shadow-lg shadow-orange-200"
              >
                Enviar Documentos
              </button>
            </div>
          )}

          <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-bold flex items-center gap-2">
                <Truck className="w-5 h-5 text-[#F97316]" />
                Meu Veículo
              </h3>
              <button 
                onClick={openProfile}
                className="text-xs font-bold text-[#F97316] hover:underline"
              >
                Editar
              </button>
            </div>
            {profile?.vehicleModel ? (
              <div className="space-y-4">
                <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Modelo</p>
                  <p className="font-bold text-[#1E293B]">{profile.vehicleModel}</p>
                </div>
                <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                  <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mb-1">Placa</p>
                  <p className="font-bold text-[#1E293B]">{profile.vehiclePlate || 'Não informada'}</p>
                </div>
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-sm text-gray-400 mb-4">Você ainda não cadastrou seu veículo.</p>
                <button 
                  onClick={openProfile}
                  className="w-full py-3 bg-orange-50 text-[#F97316] rounded-xl font-bold hover:bg-orange-100 transition-all"
                >
                  Cadastrar Agora
                </button>
              </div>
            )}
          </div>

          <div className="bg-white rounded-3xl p-8 shadow-sm border border-gray-100">
            <h3 className="text-lg font-bold mb-6">Dicas de Segurança</h3>
            <ul className="space-y-4">
              {[
                "Sempre confira a carga antes de iniciar o trajeto.",
                "Mantenha seu GPS ligado para o cliente acompanhar.",
                "Use o botão de SOS em caso de emergência."
              ].map((tip, i) => (
                <li key={i} className="flex gap-4">
                  <div className="w-6 h-6 rounded-lg bg-gray-50 flex items-center justify-center text-[#F97316] shrink-0 font-bold text-xs">
                    {i + 1}
                  </div>
                  <p className="text-sm text-gray-500 leading-relaxed">{tip}</p>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Main Content: Tabs & Lists */}
        <div className="lg:col-span-2 space-y-8 order-1 lg:order-2">
          <div className="flex p-1 bg-gray-100 rounded-2xl w-fit">
            <button
              onClick={() => setActiveTab('available')}
              className={`px-6 py-3 rounded-xl font-bold text-sm transition-all ${
                activeTab === 'available' ? 'bg-white text-[#1E293B] shadow-sm' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Disponíveis ({availableFreights.length})
            </button>
            <button
              onClick={() => setActiveTab('my')}
              className={`px-6 py-3 rounded-xl font-bold text-sm transition-all ${
                activeTab === 'my' ? 'bg-white text-[#1E293B] shadow-sm' : 'text-gray-500 hover:text-gray-700'
              }`}
            >
              Meus Fretes ({myFreights.length})
            </button>
          </div>

          <div className="space-y-4">
            {activeTab === 'available' ? (
              availableFreights.length === 0 ? (
                <div className="p-12 text-center text-gray-400 bg-white rounded-2xl border-2 border-dashed border-gray-100">
                  <Search className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                  Nenhum frete disponível no momento.
                </div>
              ) : (
                availableFreights.map(freight => (
                  <DriverFreightCard 
                    key={freight.id} 
                    freight={freight} 
                    onAction={() => handleAcceptFreight(freight.id)}
                    onViewDetails={() => setSelectedFreightId(freight.id)}
                    actionLabel="Aceitar Frete"
                  />
                ))
              )
            ) : (
              myFreights.length === 0 ? (
                <div className="p-12 text-center text-gray-400 bg-white rounded-2xl border-2 border-dashed border-gray-100">
                  <Package className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                  Você ainda não aceitou nenhum frete.
                </div>
              ) : (
                myFreights.map(freight => (
                  <DriverFreightCard 
                    key={freight.id} 
                    freight={freight} 
                    onAction={() => {
                      const nextStatus: any = {
                        accepted: 'in-transit',
                        'in-transit': 'delivered'
                      };
                      if (nextStatus[freight.status]) {
                        handleUpdateStatus(freight.id, nextStatus[freight.status]);
                      }
                    }}
                    onViewDetails={() => setSelectedFreightId(freight.id)}
                    onCancel={() => handleCancelFreight(freight.id)}
                    actionLabel={
                      freight.status === 'accepted' ? 'Iniciar Coleta' : 
                      freight.status === 'in-transit' ? 'Finalizar Entrega' : 
                      'Concluído'
                    }
                    disabled={freight.status === 'delivered' || freight.status === 'cancelled'}
                  />
                ))
              )
            )}
          </div>
        </div>
      </div>

      {/* Details Modal */}
      <AnimatePresence>
        {selectedFreightId && (
          <FreightDetails 
            freightId={selectedFreightId} 
            onClose={() => setSelectedFreightId(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function DriverFreightCard({ freight, onAction, actionLabel, disabled, onViewDetails, onCancel }: any) {
  const [client, setClient] = useState<any>(null);
  const statusColors: any = {
    pending: 'bg-yellow-50 text-yellow-600 border-yellow-100',
    accepted: 'bg-blue-50 text-blue-600 border-blue-100',
    'in-transit': 'bg-indigo-50 text-indigo-600 border-indigo-100',
    delivered: 'bg-green-50 text-green-600 border-green-100',
    cancelled: 'bg-red-50 text-red-600 border-red-100'
  };

  useEffect(() => {
    if (freight.clientId) {
      const unsubscribe = onSnapshot(doc(db, 'users', freight.clientId), (doc) => {
        if (doc.exists()) {
          setClient(doc.data());
        }
      });
      return () => unsubscribe();
    }
  }, [freight.clientId]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all"
    >
      <div className="flex flex-col sm:flex-row gap-6">
        <div className="flex-1 space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {client ? (
                <div className="flex items-center gap-3">
                  <img 
                    src={client.photoUrl || `https://picsum.photos/seed/${client.uid}/100/100`} 
                    className="w-10 h-10 rounded-full object-cover border-2 border-white shadow-sm" 
                    alt="" 
                  />
                  <div>
                    <p className="text-[10px] text-gray-400 uppercase font-bold tracking-wider">Solicitante</p>
                    <p className="text-sm font-bold text-[#1E293B]">{client.name}</p>
                  </div>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <div className="w-10 h-10 rounded-full bg-gray-50 flex items-center justify-center">
                    <Truck className="w-5 h-5 text-[#F97316]" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 uppercase font-bold tracking-wider">Veículo Necessário</p>
                    <p className="text-sm font-bold text-[#1E293B] capitalize">{freight.vehicleType}</p>
                  </div>
                </div>
              )}
              {freight.status !== 'pending' && (
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold border ${statusColors[freight.status]}`}>
                  {freight.status.toUpperCase()}
                </span>
              )}
              {freight.isPremium && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-400 text-white flex items-center gap-1">
                  <Star className="w-2.5 h-2.5 fill-current" />
                  PREMIUM
                </span>
              )}
            </div>
            <p className="text-xl font-black text-[#F97316]">R$ {freight.price.toFixed(2)}</p>
          </div>

          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="mt-1 w-2 h-2 rounded-full bg-blue-500" />
              <div>
                <p className="text-xs text-gray-400 uppercase font-bold tracking-wider">Origem</p>
                <p className="text-sm font-medium text-gray-700">{freight.origin.address}</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="mt-1 w-2 h-2 rounded-full bg-[#F97316]" />
              <div>
                <p className="text-xs text-gray-400 uppercase font-bold tracking-wider">Destino</p>
                <p className="text-sm font-medium text-gray-700">{freight.destination.address}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="sm:w-48 flex flex-col justify-center border-t sm:border-t-0 sm:border-l border-gray-100 pt-4 sm:pt-0 sm:pl-6">
          <div className="mb-4 text-center sm:text-left">
            <p className="text-xs text-gray-400 uppercase font-bold tracking-wider mb-1">Distância</p>
            <p className="text-lg font-bold text-[#1E293B]">{freight.distance.toFixed(1)} km</p>
            <p className="text-[10px] text-gray-400 font-bold uppercase mt-1">Veículo: {freight.vehicleType}</p>
          </div>
          <div className="space-y-2">
            <button
              disabled={disabled}
              onClick={onAction}
              className="w-full py-3 bg-[#1E293B] text-white rounded-xl font-bold hover:bg-[#2d3d57] transition-all shadow-lg shadow-blue-900/10 disabled:opacity-50 disabled:bg-gray-100 disabled:text-gray-400 disabled:shadow-none"
            >
              {actionLabel}
            </button>
            <div className="flex gap-2">
              <button
                onClick={onViewDetails}
                className="flex-1 py-2.5 bg-gray-50 text-[#1E293B] rounded-xl text-sm font-bold hover:bg-gray-100 transition-all"
              >
                Detalhes
              </button>
              {onCancel && freight.status === 'accepted' && (
                <button
                  onClick={onCancel}
                  className="px-3 py-2.5 bg-red-50 text-red-500 rounded-xl text-sm font-bold hover:bg-red-100 transition-all"
                >
                  <XCircle className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
