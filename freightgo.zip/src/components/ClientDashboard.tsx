import React, { useState, useEffect } from 'react';
import { useAuth, UserProfile } from '../App';
import { db, collection, query, where, onSnapshot, orderBy, limit, handleFirestoreError, OperationType, setDoc, doc, auth } from '../firebase';
import { Plus, Truck, MapPin, Navigation, Package, Star, LogOut, Clock, CheckCircle, XCircle, AlertCircle, ChevronRight, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import FreightDetails from './FreightDetails';
import UserMenu from './UserMenu';

// Fix Leaflet marker icon issue
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';
let DefaultIcon = L.icon({
    iconUrl: icon,
    shadowUrl: iconShadow,
    iconSize: [25, 41],
    iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

const BRAZIL_STATES = [
  'AC', 'AL', 'AP', 'AM', 'BA', 'CE', 'DF', 'ES', 'GO', 'MA', 'MT', 'MS', 'MG', 'PA', 'PB', 'PR', 'PE', 'PI', 'RJ', 'RN', 'RS', 'RO', 'RR', 'SC', 'SP', 'SE', 'TO'
];

function MapUpdater({ center, zoom }: { center: [number, number], zoom: number }) {
  const map = useMapEvents({});
  useEffect(() => {
    const timer = setTimeout(() => {
      map.invalidateSize();
      map.setView(center, zoom);
    }, 250);
    return () => clearTimeout(timer);
  }, [center, zoom, map]);
  return null;
}

export default function ClientDashboard() {
  const { profile, signOut, switchRole, openHelp } = useAuth();
  const [freights, setFreights] = useState<any[]>([]);
  const [topDrivers, setTopDrivers] = useState<UserProfile[]>([]);
  const [driverLocations, setDriverLocations] = useState<any[]>([]);
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [selectedFreightId, setSelectedFreightId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!profile) return;

    // Fetch client's freights
    const q = query(
      collection(db, 'freights'),
      where('clientId', '==', profile.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribeFreights = onSnapshot(q, (snapshot) => {
      setFreights(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'freights');
    });

    // Fetch top drivers
    const driversQ = query(
      collection(db, 'users'),
      where('role', '==', 'driver'),
      orderBy('rating', 'desc'),
      limit(3)
    );

    const unsubscribeDrivers = onSnapshot(driversQ, (snapshot) => {
      setTopDrivers(snapshot.docs.map(doc => doc.data() as UserProfile));
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'users');
    });

    // Listen to driver locations
    const locationsQ = collection(db, 'locations');
    const unsubscribeLocations = onSnapshot(locationsQ, (snapshot) => {
      const now = new Date();
      const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000);
      
      const activeLocations = snapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() } as any))
        .filter(loc => new Date(loc.updatedAt) > fiveMinutesAgo);
        
      setDriverLocations(activeLocations);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'locations');
    });

    return () => {
      unsubscribeFreights();
      unsubscribeDrivers();
      unsubscribeLocations();
    };
  }, [profile]);

  // Find active freight driver location
  const activeFreight = freights.find(f => f.status === 'in-transit');
  const activeDriverLocation = activeFreight ? driverLocations.find(l => l.id === activeFreight.driverId) : null;

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      {/* Header */}
      <header className="flex items-center justify-between mb-12">
        <div className="flex items-center gap-3">
          <Truck className="w-10 h-10 text-[#F97316]" />
          <h1 className="text-3xl font-black tracking-tighter text-[#1E293B]">FreightGo</h1>
        </div>
        <div className="flex items-center gap-6">
          <UserMenu />
        </div>
      </header>

      <div className="grid lg:grid-cols-3 gap-8">
        {/* Main Content: Freight List */}
        <div className="lg:col-span-2 space-y-8">
          <div className="flex items-center justify-between">
            <h2 className="text-2xl font-bold flex items-center gap-2">
              <Package className="w-6 h-6 text-[#F97316]" />
              Meus Fretes
            </h2>
            <button
              onClick={() => setShowRequestModal(true)}
              className="flex items-center gap-2 px-6 py-3 bg-[#1E293B] text-white rounded-xl font-bold hover:bg-[#2d3d57] transition-all shadow-lg shadow-blue-900/10"
            >
              <Plus className="w-5 h-5" />
              Novo Frete
            </button>
          </div>

          <div className="space-y-4">
            {loading ? (
              <div className="p-12 text-center text-gray-400">Carregando seus fretes...</div>
            ) : freights.length === 0 ? (
              <div className="p-12 bg-white rounded-2xl border-2 border-dashed border-gray-100 text-center">
                <Package className="w-12 h-12 text-gray-200 mx-auto mb-4" />
                <p className="text-gray-500 font-medium">Você ainda não solicitou nenhum frete.</p>
                <button
                  onClick={() => setShowRequestModal(true)}
                  className="mt-4 text-[#F97316] font-bold hover:underline"
                >
                  Solicite seu primeiro frete agora
                </button>
              </div>
            ) : (
              freights.map((freight) => (
                <FreightCard 
                  key={freight.id} 
                  freight={freight} 
                  onViewDetails={() => setSelectedFreightId(freight.id)} 
                />
              ))
            )}
          </div>
        </div>

        {/* Sidebar: Top Drivers & Stats */}
        <div className="space-y-8">
          <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
            <h3 className="text-xl font-bold mb-6 flex items-center gap-2">
              <Star className="w-5 h-5 text-yellow-400 fill-yellow-400" />
              Top Motoristas
            </h3>
            <div className="space-y-4">
              {topDrivers.map((driver, i) => (
                <div key={driver.uid} className="flex items-center gap-4 p-3 rounded-xl hover:bg-gray-50 transition-all cursor-pointer group">
                  <div className="relative">
                    <img
                      src={driver.photoUrl || `https://picsum.photos/seed/${driver.uid}/100/100`}
                      alt={driver.name}
                      className="w-12 h-12 rounded-full object-cover border-2 border-white shadow-sm"
                    />
                    <div className="absolute -top-1 -left-1 w-5 h-5 bg-[#F97316] text-white text-[10px] font-bold rounded-full flex items-center justify-center border-2 border-white">
                      {i + 1}
                    </div>
                  </div>
                  <div className="flex-1">
                    <p className="font-bold text-sm group-hover:text-[#F97316] transition-all">{driver.name}</p>
                    <div className="flex items-center gap-1 text-xs text-gray-500">
                      <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                      <span>{driver.rating?.toFixed(1)}</span>
                      <span className="mx-1">•</span>
                      <span>{driver.totalRatings} entregas</span>
                    </div>
                  </div>
                  <ChevronRight className="w-4 h-4 text-gray-300 group-hover:text-gray-400" />
                </div>
              ))}
            </div>
          </div>

          <div className="bg-[#1E293B] rounded-2xl p-6 text-white overflow-hidden relative">
            <div className="relative z-10">
              <h3 className="text-lg font-bold mb-2">Precisa de ajuda?</h3>
              <p className="text-gray-400 text-sm mb-6">Nossa central de suporte está disponível 24/7 para você.</p>
              <button 
                onClick={openHelp}
                className="w-full py-3 bg-[#F97316] text-white rounded-xl font-bold hover:bg-[#fa8533] transition-all"
              >
                Falar com Suporte
              </button>
            </div>
            <Truck className="absolute -bottom-4 -right-4 w-24 h-24 text-white/5 rotate-12" />
          </div>
        </div>
      </div>

      {/* Request Modal */}
      <AnimatePresence>
        {showRequestModal && (
          <FreightRequestModal onClose={() => setShowRequestModal(false)} />
        )}
      </AnimatePresence>

      {/* Details Modal */}
      <AnimatePresence>
        {selectedFreightId && (
          <FreightDetails 
            freightId={selectedFreightId} 
            onClose={() => setSelectedFreightId(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}

function FreightCard({ freight, onViewDetails }: any) {
  const [driver, setDriver] = useState<any>(null);
  const statusColors: any = {
    pending: 'bg-yellow-50 text-yellow-600 border-yellow-100',
    accepted: 'bg-blue-50 text-blue-600 border-blue-100',
    'in-transit': 'bg-indigo-50 text-indigo-600 border-indigo-100',
    delivered: 'bg-green-50 text-green-600 border-green-100',
    cancelled: 'bg-red-50 text-red-600 border-red-100'
  };

  const statusIcons: any = {
    pending: Clock,
    accepted: CheckCircle,
    'in-transit': Navigation,
    delivered: CheckCircle,
    cancelled: XCircle
  };

  useEffect(() => {
    if (freight.driverId) {
      const unsubscribe = onSnapshot(doc(db, 'users', freight.driverId), (doc) => {
        if (doc.exists()) {
          setDriver(doc.data());
        }
      });
      return () => unsubscribe();
    }
  }, [freight.driverId]);

  const StatusIcon = statusIcons[freight.status] || AlertCircle;

  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-all group"
    >
      <div className="flex flex-col sm:flex-row gap-6">
        <div className="flex-1 space-y-4">
          <div className="flex items-center justify-between">
            <div className={`px-3 py-1 rounded-full text-xs font-bold border flex items-center gap-1.5 ${statusColors[freight.status]}`}>
              <StatusIcon className="w-3.5 h-3.5" />
              {freight.status.toUpperCase()}
            </div>
            <p className="text-lg font-black text-[#1E293B]">R$ {freight.price.toFixed(2)}</p>
          </div>

          <div className="space-y-3">
            <div className="flex items-start gap-3">
              <div className="mt-1 w-2 h-2 rounded-full bg-blue-500" />
              <div>
                <p className="text-xs text-gray-400 uppercase font-bold tracking-wider">Origem</p>
                <p className="text-sm font-medium text-gray-700">{freight.origin.address}</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="mt-1 w-2 h-2 rounded-full bg-[#F97316]" />
              <div>
                <p className="text-xs text-gray-400 uppercase font-bold tracking-wider">Destino</p>
                <p className="text-sm font-medium text-gray-700">{freight.destination.address}</p>
              </div>
            </div>
          </div>
        </div>

        <div className="sm:w-64 flex flex-col justify-between border-t sm:border-t-0 sm:border-l border-gray-100 pt-4 sm:pt-0 sm:pl-6">
          <div className="space-y-4">
            {driver ? (
              <div className="flex items-center gap-3 p-2 bg-gray-50 rounded-xl border border-gray-100">
                <img 
                  src={driver.photoUrl || `https://picsum.photos/seed/${driver.uid}/100/100`} 
                  className="w-10 h-10 rounded-full object-cover border-2 border-white shadow-sm" 
                  alt="" 
                />
                <div className="flex-1 min-w-0">
                  <p className="text-xs font-bold text-[#1E293B] truncate">{driver.name}</p>
                  <p className="text-[9px] text-gray-400 font-bold uppercase truncate">
                    {driver.vehicleModel || freight.vehicleType} • {driver.vehiclePlate || 'S/ Placa'}
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">Veículo</span>
                  <span className="font-bold text-[#1E293B] capitalize">{freight.vehicleType}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">Distância</span>
                  <span className="font-bold text-[#1E293B]">{freight.distance.toFixed(1)} km</span>
                </div>
              </div>
            )}
          </div>
          <button 
            onClick={onViewDetails}
            className="mt-4 w-full py-2.5 bg-gray-50 text-[#1E293B] rounded-lg text-sm font-bold hover:bg-gray-100 transition-all flex items-center justify-center gap-2"
          >
            Ver Detalhes
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </motion.div>
  );
}

function FreightRequestModal({ onClose }: { onClose: () => void }) {
  const { profile } = useAuth();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    origin: '',
    destination: '',
    originCity: '',
    originState: '',
    destCity: '',
    destState: '',
    vehicleType: 'moto' as 'moto' | 'car' | 'truck',
    isPremium: false,
    originCoords: [-23.5505, -46.6333] as [number, number],
    destCoords: [-23.5505, -46.6333] as [number, number]
  });

  const [originSuggestions, setOriginSuggestions] = useState<any[]>([]);
  const [destSuggestions, setDestSuggestions] = useState<any[]>([]);
  const [originCitySuggestions, setOriginCitySuggestions] = useState<any[]>([]);
  const [destCitySuggestions, setDestCitySuggestions] = useState<any[]>([]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (formData.originCity.length >= 3 && formData.originState) {
        fetchCitySuggestions(formData.originCity, formData.originState, setOriginCitySuggestions);
      } else {
        setOriginCitySuggestions([]);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [formData.originCity, formData.originState]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (formData.destCity.length >= 3 && formData.destState) {
        fetchCitySuggestions(formData.destCity, formData.destState, setDestCitySuggestions);
      } else {
        setDestCitySuggestions([]);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [formData.destCity, formData.destState]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (formData.origin.length >= 3 && formData.originCity && formData.originState) {
        fetchSuggestions(formData.origin, formData.originCity, formData.originState, setOriginSuggestions);
      } else {
        setOriginSuggestions([]);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [formData.origin, formData.originCity, formData.originState]);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (formData.destination.length >= 3 && formData.destCity && formData.destState) {
        fetchSuggestions(formData.destination, formData.destCity, formData.destState, setDestSuggestions);
      } else {
        setDestSuggestions([]);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [formData.destination, formData.destCity, formData.destState]);

  const fetchCitySuggestions = async (query: string, state: string, setSuggestions: (s: any[]) => void) => {
    try {
      const fullQuery = `${query}, ${state}, Brasil`;
      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(fullQuery)}&featuretype=settlement&addressdetails=1&limit=5`);
      const data = await response.json();
      setSuggestions(data);
    } catch (error) {
      console.error("Error fetching city suggestions:", error);
    }
  };

  const fetchSuggestions = async (query: string, city: string, state: string, setSuggestions: (s: any[]) => void) => {
    try {
      const fullQuery = `${query}, ${city}, ${state}, Brasil`;
      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(fullQuery)}&addressdetails=1&limit=5`);
      const data = await response.json();
      setSuggestions(data);
    } catch (error) {
      console.error("Error fetching suggestions:", error);
    }
  };

  const updateMapFromCity = async (city: string, state: string, type: 'origin' | 'dest') => {
    if (!city || !state) return;
    try {
      const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&city=${encodeURIComponent(city)}&state=${encodeURIComponent(state)}&country=Brasil&limit=1`);
      const data = await response.json();
      if (data && data.length > 0) {
        const coords: [number, number] = [parseFloat(data[0].lat), parseFloat(data[0].lon)];
        setFormData(prev => ({
          ...prev,
          [type === 'origin' ? 'originCoords' : 'destCoords']: coords
        }));
      }
    } catch (error) {
      console.error("Error updating map from city:", error);
    }
  };

  function LocationPicker({ onPick, position }: { onPick: (coords: [number, number]) => void, position: [number, number] }) {
    useMapEvents({
      click(e) {
        onPick([e.latlng.lat, e.latlng.lng]);
      },
    });
    return (
      <Marker 
        position={position} 
        icon={L.divIcon({
          className: 'custom-div-icon',
          html: `<div style="background-color: #F97316; width: 20px; height: 20px; border-radius: 50%; border: 4px solid white; box-shadow: 0 0 20px rgba(249, 115, 22, 0.7);"></div>`,
          iconSize: [20, 20],
          iconAnchor: [10, 10]
        })}
      />
    );
  }

  const handleUseMyLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition((position) => {
        const coords: [number, number] = [position.coords.latitude, position.coords.longitude];
        setFormData(prev => ({ 
          ...prev, 
          originCoords: coords,
          origin: `Localização Atual (${coords[0].toFixed(4)}, ${coords[1].toFixed(4)})` 
        }));
        setStep(2); // Go to map refinement
      }, (error) => {
        console.error("Erro ao obter localização:", error);
      });
    }
  };

  const calculatePrice = (dist: number, type: string, isPremium: boolean) => {
    const factors: any = { moto: 1.5, car: 2.5, truck: 5.0 };
    let price = dist * factors[type];
    if (isPremium) price *= 1.5;
    return price;
  };

  const handleSubmit = async () => {
    if (!profile) return;
    setLoading(true);
    
    const latDiff = formData.destCoords[0] - formData.originCoords[0];
    const lngDiff = formData.destCoords[1] - formData.originCoords[1];
    const distance = Math.sqrt(latDiff * latDiff + lngDiff * lngDiff) * 111;
    const price = calculatePrice(distance, formData.vehicleType, formData.isPremium);

    const freightData = {
      clientId: profile.uid,
      origin: { 
        address: formData.origin, 
        city: formData.originCity, 
        state: formData.originState,
        lat: formData.originCoords[0], 
        lng: formData.originCoords[1] 
      },
      destination: { 
        address: formData.destination, 
        city: formData.destCity, 
        state: formData.destState,
        lat: formData.destCoords[0], 
        lng: formData.destCoords[1] 
      },
      distance,
      price,
      status: 'pending',
      vehicleType: formData.vehicleType,
      isPremium: formData.isPremium,
      createdAt: new Date().toISOString()
    };

    try {
      const newFreightRef = doc(collection(db, 'freights'));
      await setDoc(newFreightRef, { ...freightData, id: newFreightRef.id });
      onClose();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'freights');
    } finally {
      setLoading(false);
    }
  };

  const nextStep = () => setStep(prev => prev + 1);
  const prevStep = () => setStep(prev => prev - 1);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-[#1E293B]/60 backdrop-blur-sm">
      <motion.div
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.95 }}
        className="bg-white rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl"
      >
        <div className="p-8">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-2xl font-bold">Solicitar Frete</h2>
              <p className="text-sm text-gray-500">Passo {step} de 5</p>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded-full transition-all">
              <XCircle className="w-6 h-6 text-gray-400" />
            </button>
          </div>

          <div className="space-y-6 min-h-[400px]">
            <AnimatePresence mode="wait">
              {step === 1 && (
                <motion.div
                  key="step1"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-4"
                >
                  <div className="flex items-center justify-between">
                    <label className="text-sm font-bold text-gray-500 uppercase tracking-wider">Endereço de Origem</label>
                    <button 
                      onClick={handleUseMyLocation}
                      className="text-xs font-bold text-[#F97316] flex items-center gap-1 hover:underline"
                    >
                      <Navigation className="w-3 h-3" />
                      Usar minha localização
                    </button>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <select
                      className="w-full px-4 py-3 bg-gray-50 border-2 border-transparent focus:border-[#F97316] focus:bg-white rounded-xl transition-all outline-none text-sm"
                      value={formData.originState}
                      onChange={(e) => {
                        setFormData({ ...formData, originState: e.target.value });
                        updateMapFromCity(formData.originCity, e.target.value, 'origin');
                      }}
                    >
                      <option value="">UF</option>
                      {BRAZIL_STATES.map(uf => <option key={uf} value={uf}>{uf}</option>)}
                    </select>
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="Cidade"
                        className="w-full px-4 py-3 bg-gray-50 border-2 border-transparent focus:border-[#F97316] focus:bg-white rounded-xl transition-all outline-none text-sm"
                        value={formData.originCity}
                        onChange={(e) => setFormData({ ...formData, originCity: e.target.value })}
                        onBlur={() => {
                          setTimeout(() => setOriginCitySuggestions([]), 200);
                          updateMapFromCity(formData.originCity, formData.originState, 'origin');
                        }}
                      />
                      {originCitySuggestions.length > 0 && (
                        <div className="absolute z-50 left-0 right-0 mt-2 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden">
                          {originCitySuggestions.map((s, i) => (
                            <button
                              key={i}
                              className="w-full text-left px-4 py-3 hover:bg-gray-50 text-sm border-b border-gray-50 last:border-0"
                              onClick={() => {
                                const cityName = s.address.city || s.address.town || s.address.village || s.display_name.split(',')[0];
                                setFormData({
                                  ...formData,
                                  originCity: cityName,
                                  originCoords: [parseFloat(s.lat), parseFloat(s.lon)]
                                });
                                setOriginCitySuggestions([]);
                              }}
                            >
                              {s.address.city || s.address.town || s.address.village || s.display_name.split(',')[0]}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="relative">
                    <MapPin className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Rua e número"
                      className="w-full pl-12 pr-4 py-4 bg-gray-50 border-2 border-transparent focus:border-[#F97316] focus:bg-white rounded-2xl transition-all outline-none"
                      value={formData.origin}
                      onChange={(e) => setFormData({ ...formData, origin: e.target.value })}
                      onBlur={() => setTimeout(() => setOriginSuggestions([]), 200)}
                    />
                    {originSuggestions.length > 0 && (
                      <div className="absolute z-50 left-0 right-0 mt-2 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden">
                        {originSuggestions.map((s, i) => (
                          <button
                            key={i}
                            className="w-full text-left px-4 py-3 hover:bg-gray-50 text-sm border-b border-gray-50 last:border-0"
                            onClick={() => {
                              const simplified = s.address.road ? `${s.address.road}${s.address.house_number ? `, ${s.address.house_number}` : ''}` : s.display_name.split(',')[0];
                              setFormData({
                                ...formData,
                                origin: simplified,
                                originCoords: [parseFloat(s.lat), parseFloat(s.lon)]
                              });
                              setOriginSuggestions([]);
                            }}
                          >
                            {s.address.road ? `${s.address.road}${s.address.house_number ? `, ${s.address.house_number}` : ''}` : s.display_name.split(',')[0]}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {step === 2 && (
                <motion.div
                  key="step2"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-4"
                >
                  <label className="text-sm font-bold text-gray-500 uppercase tracking-wider">Refinar Local de Origem</label>
                  <p className="text-xs text-gray-400">Arraste o mapa ou clique para ajustar o ponto exato da retirada.</p>
                  <div className="h-80 rounded-2xl overflow-hidden border-2 border-gray-100">
                    <MapContainer 
                      key={`step2-${formData.originCoords[0]}-${formData.originCoords[1]}`}
                      center={formData.originCoords} 
                      zoom={16} 
                      style={{ height: '100%', width: '100%' }}
                    >
                      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                      <MapUpdater center={formData.originCoords} zoom={16} />
                      <LocationPicker 
                        position={formData.originCoords} 
                        onPick={(coords) => setFormData({ ...formData, originCoords: coords })} 
                      />
                    </MapContainer>
                  </div>
                </motion.div>
              )}

              {step === 3 && (
                <motion.div
                  key="step3"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-4"
                >
                  <label className="text-sm font-bold text-gray-500 uppercase tracking-wider">Endereço de Destino</label>
                  <div className="grid grid-cols-2 gap-3">
                    <select
                      className="w-full px-4 py-3 bg-gray-50 border-2 border-transparent focus:border-[#F97316] focus:bg-white rounded-xl transition-all outline-none text-sm"
                      value={formData.destState}
                      onChange={(e) => {
                        setFormData({ ...formData, destState: e.target.value });
                        updateMapFromCity(formData.destCity, e.target.value, 'dest');
                      }}
                    >
                      <option value="">UF</option>
                      {BRAZIL_STATES.map(uf => <option key={uf} value={uf}>{uf}</option>)}
                    </select>
                    <div className="relative">
                      <input
                        type="text"
                        placeholder="Cidade"
                        className="w-full px-4 py-3 bg-gray-50 border-2 border-transparent focus:border-[#F97316] focus:bg-white rounded-xl transition-all outline-none text-sm"
                        value={formData.destCity}
                        onChange={(e) => setFormData({ ...formData, destCity: e.target.value })}
                        onBlur={() => {
                          setTimeout(() => setDestCitySuggestions([]), 200);
                          updateMapFromCity(formData.destCity, formData.destState, 'dest');
                        }}
                      />
                      {destCitySuggestions.length > 0 && (
                        <div className="absolute z-50 left-0 right-0 mt-2 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden">
                          {destCitySuggestions.map((s, i) => (
                            <button
                              key={i}
                              className="w-full text-left px-4 py-3 hover:bg-gray-50 text-sm border-b border-gray-50 last:border-0"
                              onClick={() => {
                                const cityName = s.address.city || s.address.town || s.address.village || s.display_name.split(',')[0];
                                setFormData({
                                  ...formData,
                                  destCity: cityName,
                                  destCoords: [parseFloat(s.lat), parseFloat(s.lon)]
                                });
                                setDestCitySuggestions([]);
                              }}
                            >
                              {s.address.city || s.address.town || s.address.village || s.display_name.split(',')[0]}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="relative">
                    <Navigation className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Rua e número"
                      className="w-full pl-12 pr-4 py-4 bg-gray-50 border-2 border-transparent focus:border-[#F97316] focus:bg-white rounded-2xl transition-all outline-none"
                      value={formData.destination}
                      onChange={(e) => setFormData({ ...formData, destination: e.target.value })}
                      onBlur={() => setTimeout(() => setDestSuggestions([]), 200)}
                    />
                    {destSuggestions.length > 0 && (
                      <div className="absolute z-50 left-0 right-0 mt-2 bg-white rounded-xl shadow-xl border border-gray-100 overflow-hidden">
                        {destSuggestions.map((s, i) => (
                          <button
                            key={i}
                            className="w-full text-left px-4 py-3 hover:bg-gray-50 text-sm border-b border-gray-50 last:border-0"
                            onClick={() => {
                              const simplified = s.address.road ? `${s.address.road}${s.address.house_number ? `, ${s.address.house_number}` : ''}` : s.display_name.split(',')[0];
                              setFormData({
                                ...formData,
                                destination: simplified,
                                destCoords: [parseFloat(s.lat), parseFloat(s.lon)]
                              });
                              setDestSuggestions([]);
                            }}
                          >
                            {s.address.road ? `${s.address.road}${s.address.house_number ? `, ${s.address.house_number}` : ''}` : s.display_name.split(',')[0]}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </motion.div>
              )}

              {step === 4 && (
                <motion.div
                  key="step4"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-4"
                >
                  <label className="text-sm font-bold text-gray-500 uppercase tracking-wider">Refinar Local de Entrega</label>
                  <p className="text-xs text-gray-400">Arraste o mapa ou clique para ajustar o ponto exato da entrega.</p>
                  <div className="h-80 rounded-2xl overflow-hidden border-2 border-gray-100">
                    <MapContainer 
                      key={`step4-${formData.destCoords[0]}-${formData.destCoords[1]}`}
                      center={formData.destCoords} 
                      zoom={16} 
                      style={{ height: '100%', width: '100%' }}
                    >
                      <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
                      <MapUpdater center={formData.destCoords} zoom={16} />
                      <LocationPicker 
                        position={formData.destCoords} 
                        onPick={(coords) => setFormData({ ...formData, destCoords: coords })} 
                      />
                    </MapContainer>
                  </div>
                </motion.div>
              )}

              {step === 5 && (
                <motion.div
                  key="step5"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-6"
                >
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-500 uppercase tracking-wider">Tipo de Veículo</label>
                    <div className="grid grid-cols-3 gap-3">
                      {['moto', 'car', 'truck'].map((type) => (
                        <button
                          key={type}
                          onClick={() => setFormData({ ...formData, vehicleType: type as any })}
                          className={`py-3 rounded-xl border-2 transition-all font-bold capitalize ${
                            formData.vehicleType === type ? 'border-[#F97316] bg-orange-50 text-[#F97316]' : 'border-gray-100 text-gray-400'
                          }`}
                        >
                          {type === 'moto' ? 'Moto' : type === 'car' ? 'Carro' : 'Caminhão'}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-bold text-gray-500 uppercase tracking-wider">Serviço Adicional</label>
                    <button
                      onClick={() => setFormData({ ...formData, isPremium: !formData.isPremium })}
                      className={`w-full p-4 rounded-2xl border-2 transition-all flex items-center justify-between ${
                        formData.isPremium ? 'border-amber-400 bg-amber-50' : 'border-gray-100 bg-white'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${formData.isPremium ? 'bg-amber-400 text-white' : 'bg-gray-100 text-gray-400'}`}>
                          <Star className="w-5 h-5" />
                        </div>
                        <div className="text-left">
                          <p className={`font-bold ${formData.isPremium ? 'text-amber-700' : 'text-gray-600'}`}>Serviço Premium</p>
                          <p className="text-xs text-gray-400">Entrega prioritária e suporte 24h (+50%)</p>
                        </div>
                      </div>
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                        formData.isPremium ? 'border-amber-400 bg-amber-400' : 'border-gray-200'
                      }`}>
                        {formData.isPremium && <CheckCircle className="w-4 h-4 text-white" />}
                      </div>
                    </button>
                  </div>

                  <div className="bg-gray-50 p-6 rounded-2xl space-y-3">
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Origem:</span>
                      <span className="font-bold text-right max-w-[200px] truncate">{formData.origin}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-gray-500">Destino:</span>
                      <span className="font-bold text-right max-w-[200px] truncate">{formData.destination}</span>
                    </div>
                    <div className="pt-3 border-t border-gray-200 flex justify-between items-center">
                      <span className="font-bold text-gray-700">Estimativa:</span>
                      <span className="text-xl font-black text-[#F97316]">
                        R$ {calculatePrice(Math.sqrt(Math.pow(formData.destCoords[0]-formData.originCoords[0], 2) + Math.pow(formData.destCoords[1]-formData.originCoords[1], 2)) * 111, formData.vehicleType, formData.isPremium).toFixed(2)}
                      </span>
                    </div>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <div className="mt-10 flex gap-4">
            {step > 1 ? (
              <button
                onClick={prevStep}
                className="flex-1 py-4 bg-gray-100 text-gray-600 rounded-2xl font-bold hover:bg-gray-200 transition-all"
              >
                Voltar
              </button>
            ) : (
              <button
                onClick={onClose}
                className="flex-1 py-4 bg-gray-100 text-gray-600 rounded-2xl font-bold hover:bg-gray-200 transition-all"
              >
                Cancelar
              </button>
            )}
            
            {step < 5 ? (
              <button
                disabled={
                  (step === 1 && (!formData.origin || !formData.originCity || !formData.originState)) ||
                  (step === 3 && (!formData.destination || !formData.destCity || !formData.destState))
                }
                onClick={nextStep}
                className="flex-[2] py-4 bg-[#F97316] text-white rounded-2xl font-bold hover:bg-[#EA580C] transition-all shadow-lg shadow-orange-900/20 disabled:opacity-50"
              >
                Próximo
              </button>
            ) : (
              <button
                disabled={loading}
                onClick={handleSubmit}
                className="flex-[2] py-4 bg-[#1E293B] text-white rounded-2xl font-bold hover:bg-[#2d3d57] transition-all shadow-lg shadow-blue-900/20 disabled:opacity-50"
              >
                {loading ? 'Processando...' : 'Confirmar Solicitação'}
              </button>
            )}
          </div>
        </div>
      </motion.div>
    </div>
  );
}
